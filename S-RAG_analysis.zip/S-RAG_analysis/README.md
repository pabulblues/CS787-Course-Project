# S-RAG Analysis

The paper is available at [S-RAG: A Novel Audit Framework for Detecting Unauthorized Use of Personal Data in RAG Systems](https://aclanthology.org/2025.acl-long.512.pdf).

## Abstract

The paper proposes S-RAG (Shadow RAG Auditing Data Provenance), a framework to audit retrieval-augmented generation (RAG) systems for unauthorized use of personal textual data. It constructs a shadow RAG system and analyzes next-word prediction behavior to infer whether a user’s data is present in the target system’s external database. This allows individuals to check if their data was used, even in strict black-box settings, and links auditing to real-world data protection requirements like GDPR. We use S-RAG to audit our baseline models and find that they often retrieve and generate personal data without consent, demonstrating the framework’s effectiveness.

In our reproduction, we evaluate S-RAG on a subset of the ChatDoctor dataset used for our the original paper. Due to GPU memory constraints, we substitute the \texttt{gpt2-xl} model with a smaller \texttt{gpt2} model for both token generation and segmentation. Under this setting, our best validation performance reaches an accuracy of 0.59 and an AUC of 0.532, with test accuracy (ACC) of 0.556, precision (PRE) of 0.560, recall (REC) of 0.519, and F1-score of 0.539. The performance gap relative to the reported results is therefore likely influenced by both the change in dataset (from HealthCareMagic-100k to the larger and potentially more heterogeneous \texttt{ChatDoctor} corpus) and the use of a smaller generic language model for next-token prediction, which may weaken the quality of the probability-based features used by the auditing classifier.
![Audit_pipline.png](./imgs/Audit_pipline.png)

## Directory Structure
|-- S-RAG_analysis
    |-- Audit.py
    |-- evaluation.py
    |-- Data
    |   |-- HealthCareMagic-100k-en.jsonl
    |-- Model	
    |   |-- (install models here)
    |-- requirements.txt
    |-- Result
    |	|-- (target and llm generated probabilities)
    |-- README.md
    |--AutogluonModels
    |	|-- (Auditor model)



## Environmental installation

Installing GPU-related libraries compatible with cuda version
```
pip3 install torch torchvision torchaudio
```

Models are to be stored in the folder `.\Model`. 

Install the following models seperately:
- llama-2-7b-chat (same as the one used in our original implementation)
- gpt2 (can be downloaded from hugging face)
- bge-large-en-v1.5 (can be downloaded from hugging face)

```
|-- Model
    |-- llama-2-7b-chat
    |   |-- checklist.chk
    |   |-- consolidated.00.pth
    |   |-- params.json
```


Install from the `requirements.txt` file:

```
pip install -r requirements.txt
```

## About the data
<!-- 
You can also find the origin datasets here: [HealthCareMagic-100k](https://huggingface.co/datasets/RafaelMPereira/HealthCareMagic-100k-Chat-Format-en)
Please unzip the datasets to the `.\Data` folder, you may find the following file structure.

```
|-- Data
    |-- HealthCareMagic-100k-en.jsonl
    |-- <other dataset>

``` -->
The subset of ChatDoctor dataset used in our experiments can be found in the `.\Data` folder as `HealthCareMagic-100k-en.jsonl`. This subset contains 100,000 samples randomly selected from the original ChatDoctor dataset due to computational resource constraints. This subset is then converted into jsonl format for easier processing.


## Examples and illustrate

There are 3 steps to run the experiment: preparation, audit and evaluation results. Below is a brief introduction on how to run these Python script files, with detailed comments available for reference in each file.

### 1. preparation

In this section, we perform pre-processing on the datasets, construct the shadow RAG system and train an audit model.

You can use the following code to construct the shadow RAG for the training set of `HealthCare` using the `llama3` model and train an audit model.

```
python Audit.py \
--dataset_name="HealthCare" \
--llm="llama3" \
--mode="prepare" \
--generate_prompts=True \
--generate_feature=True \
--generate_mask=True \
--build=True \
--split=True \
--train_audit_model=True \
--defence="wo"
```

### 2. audit

To run audit, you can run following codes.

```
python Audit.py \
--dataset_name="HealthCare" \
--llm="llama3" \
--mode="audit" \
--generate_mask=True \
--generate_prompts=True \
--generate_feature=True \
--build=True \
--split=True \
--defence="wo"
```

### 3. evaluation results

After the previous part of the code has finished running, you can use the following code to evaluate the results:

```
python evaluation.py \
--dataset_name="HealthCare" \
--llm="llama3" \
--method="Audit" \
--defence="wo" \
--audit_model="AutogluonModels/ag-20251114_144748"
```

The `dataset_name` should be the same as previous code.

The `audit_model` refers to the model that was saved in step 1 of the process.

